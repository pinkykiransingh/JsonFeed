package com.partyplanner.jsonfeed;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.toolbox.ImageLoader;

import java.util.List;

public class FeedAdapter extends RecyclerView.Adapter<FeedItemHolder> {


    private List<FeedItem> mDataset;
    @Override
    public FeedItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View feedListView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.feed_item2, parent, false);
        FeedItemHolder feedItem = new FeedItemHolder(feedListView);
        return feedItem;
    }
    public FeedAdapter(List<FeedItem> myDataset) {

        mDataset = myDataset;
    }

    @Override
    public void onBindViewHolder(FeedItemHolder feedItemHolder, int position ) {
        feedItemHolder.tittle.setText(mDataset.get(position).getTitle());
        feedItemHolder.description.setText(mDataset.get(position).getDescription());
        ImageLoader imageLoader = AppController.getInstance().getImageLoader();

        String url = mDataset.get(position).getImageHref();
        if(url==null) {

        }else {
            imageLoader.get(url, ImageLoader.getImageListener(feedItemHolder.feedImage,
                    R.drawable.ic_launcher_background, R.drawable.ic_launcher_foreground));
            feedItemHolder.feedImage.setImageUrl(url, imageLoader);
        }
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }
}
