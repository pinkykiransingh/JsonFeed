package com.partyplanner.jsonfeed;

import java.util.List;

public class Feed {
    String title;
    FeedItem rows[];

}
