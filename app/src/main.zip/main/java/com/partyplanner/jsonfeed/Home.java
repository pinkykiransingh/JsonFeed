package com.partyplanner.jsonfeed;

import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;

import java.util.Arrays;
import java.util.stream.Collectors;

public class Home extends AppCompatActivity { ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_home);
        final ListView list = findViewById(R.id.my_recycler_view);
        FeedViewModel model = ViewModelProviders.of(this).get(FeedViewModel.class);
        model.getFeeds().observe(this, feed -> {


             RecyclerView mRecyclerView;
             RecyclerView.Adapter mAdapter;
             RecyclerView.LayoutManager mLayoutManager;

             TextView textView = findViewById(R.id.title);
             textView.setText(feed.title);
            mRecyclerView = findViewById(R.id.my_recycler_view);
            //mRecyclerView.setHasFixedSize(true);
            mLayoutManager = new LinearLayoutManager(this.getApplicationContext());
            mRecyclerView.setLayoutManager(mLayoutManager);
            mAdapter = new FeedAdapter(Arrays.asList(feed.rows));
            mRecyclerView.setAdapter(mAdapter);
            RecyclerView.ItemDecoration itemDecoration =
                    new DividerItemDecoration(this, LinearLayoutManager.VERTICAL);
            mRecyclerView.addItemDecoration(itemDecoration);

        });

        final Button button = findViewById(R.id.button);
        button.setOnClickListener(view ->
                model.refreshFeed());


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
