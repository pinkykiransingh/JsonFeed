package com.partyplanner.jsonfeed;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.graphics.Bitmap;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;

public class FeedViewModel extends ViewModel {
    String url = "https://dl.dropboxusercontent.com/s/2iodh4vg0eortkl/facts.json";
  //  String url ="http://upload.wikimedia.org/wikipedia/commons/thumb/6/6b/American_Beaver.jpg/220px-American_Beaver.jpg";
    Gson gson = new Gson();

    private MutableLiveData<Feed> items;

    public LiveData<Feed> getFeeds() {
        if (items == null) {
            items = new MutableLiveData<Feed>();
            refreshFeed();
        }
        return items;
    }

    public void refreshFeed() {
        StringRequest request = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Feed feed =gson.fromJson(response, Feed.class);
                        items.setValue(feed);

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
      /*  ImageRequest request = new ImageRequest(url,
                new Response.Listener<Bitmap>() {
                    @Override
                    public void onResponse(Bitmap bitmap) {
                    //    mImageView.setImageBitmap(bitmap);
                        int a;
                        a=19;
                    }
                }, 0, 0, null,
                new Response.ErrorListener() {
                    public void onErrorResponse(VolleyError error) {
                        int a;
                        a=19;
                        //mImageView.setImageResource(R.drawable.image_load_error);
                    }
                });*/
        AppController.getInstance().addToRequestQueue(request);
    }
}
